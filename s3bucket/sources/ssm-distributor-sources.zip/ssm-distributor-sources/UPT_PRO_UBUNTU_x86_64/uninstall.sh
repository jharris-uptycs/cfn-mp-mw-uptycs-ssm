#!/usr/bin/env sh

set -e

sudo systemctl stop osqueryd
